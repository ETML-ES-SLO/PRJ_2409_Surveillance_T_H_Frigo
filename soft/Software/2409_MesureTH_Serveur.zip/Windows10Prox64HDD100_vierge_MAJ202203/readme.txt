Windows 10 Pro x64 (Dreamspark) 1.03.2016
Màj SCA 4.03.2022

